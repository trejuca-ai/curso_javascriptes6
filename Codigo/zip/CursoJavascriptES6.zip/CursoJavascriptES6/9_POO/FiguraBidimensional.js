class FiguraBidimensional extends Figura {
	
	constructor(area, perimetro) {
		super(area, perimetro)
	}
}